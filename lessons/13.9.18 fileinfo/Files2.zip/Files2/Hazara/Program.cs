﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Hazara
{
	class Program
	{
		static void Main(string[] args)
		{
			/*
			//HW 1
			List<string> names = new List<string>();
			string name = Console.ReadLine();
			while (name != "done")
			{
				names.Add(name);
				name = Console.ReadLine();
			}

			FileStream namesStream = new FileStream("names.txt", FileMode.Create);
			foreach (string n in names)
			{
				byte[] data = Encoding.ASCII.GetBytes(n + Environment.NewLine); //get raw data
				namesStream.Write(data, 0, data.Length);
			}
			namesStream.Close(); //cleanup
			//*/

			//HW 2
			CountNames();
		}

		public static void CountNames()
		{
			FileStream namesStream = new FileStream("names.txt", FileMode.Open);
			StringBuilder sb = new StringBuilder();
			int b = namesStream.ReadByte(); //read next byte
			while (b != -1)
			{
				sb.Append((char)b); //cast and append to string builder
				b = namesStream.ReadByte(); //read next byte
			}

			string[] names = sb.ToString().Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);
			//*
			Console.WriteLine(sb);
			/*/
			foreach (string n in names) Console.WriteLine(n);
			//*/
			Console.WriteLine(names.Length);
		}
	}
}
