﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hazara
{
	class Grocery : Product
	{
		public Grocery(string name, double price) : base(name, price)
		{
		}
	}
}
