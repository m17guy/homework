﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Hazara
{
	class LoginManager
	{
		private string path;

		public LoginManager(string path)
		{
			this.path = path;
		}

		public void AddUser(string userName)
		{
			FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
	
			HashSet<string> uniqueNames = new HashSet<string>(ReadNames(stream));
			uniqueNames.Add(userName);

			StringBuilder sb = new StringBuilder();
			foreach (string n in uniqueNames) sb.Append(n + Environment.NewLine);

			WriteNames(stream, sb);
		}

		public void UpdateUser(string oldName, string newName)
		{
			FileStream stream = new FileStream(path, FileMode.OpenOrCreate);

			string[] names = ReadNames(stream);
			for (int i = 0; i < names.Length; i++)
			{
				if(names[i] == oldName)
				{
					names[i] = newName; //change name
					break;
				}
			}

			StringBuilder sb = new StringBuilder();
			foreach (string n in names) sb.Append(n + Environment.NewLine);

			WriteNames(stream, sb);
		}

		public void RemoveUser(string name)
		{
			FileStream stream = new FileStream(path, FileMode.OpenOrCreate);

			List<string> mNames = new List<string>(ReadNames(stream));

			for (int i = 0; i < mNames.Count; i++)
			{
				if (mNames[i] == name)
				{
					mNames.RemoveAt(i);
					break;
				}
			}

			StringBuilder sb = new StringBuilder();
			foreach (string n in mNames) sb.Append(n + Environment.NewLine);

			WriteNames(stream, sb);
		}

		private static void WriteNames(FileStream stream, StringBuilder sb)
		{
			stream.Position = 0; //write from beginning of file
			byte[] data = Encoding.ASCII.GetBytes(sb.ToString());
			stream.Write(data, 0, data.Length);

			stream.Close();
		}

		private string[] ReadNames(FileStream stream)
		{

			StringBuilder sb = new StringBuilder();
			int b;
			while ((b = stream.ReadByte()) != -1)
			{
				char c = (char)b;
				sb.Append(c);
			}

			return sb.ToString().Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);
		}
	}
}
