﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hazara
{
	class Toy : Product
	{
		public Toy(string name, double price) : base(name, price)
		{

		}
	}
}
