﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Singleton
{
	class MySingy
	{
		private static MySingy instance = new MySingy();

		public static MySingy Instance
		{
			get => instance;
		}

		private int num;

		private MySingy()
		{

		}

		public int Num
		{
			set => num = value;
			get => num;
		}
	}
}
