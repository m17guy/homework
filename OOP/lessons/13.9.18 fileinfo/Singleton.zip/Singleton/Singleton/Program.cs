﻿using System;

namespace Singleton
{
	class Program
	{
		static void Main(string[] args)
		{
			//MySingy singy = new MySingy();
			MySingy singy = MySingy.Instance;

			singy.Num = 10;
			Console.WriteLine(singy.Num);

			MySingy otherRef = MySingy.Instance;
			Console.WriteLine($"other reference - {otherRef.Num}");

			otherRef.Num = 4;
			Console.WriteLine($"singy - {singy.Num}");
		}
	}
}
