﻿using System;
using System.IO;
using System.Text;

namespace Exercises
{
	class Program
	{
		//Exercises:
		/*
		1) static void EX1() - input file name & extension, then create a file
		2) static void EX2() - input file name, then read all names from a file // "bubu,deadpool,groot,rocket"
		3) static void EX3() - input file name, delete that file

		bonus) input file name, delete all the letters 'a' inside it
		bonus) 
		 */


		static void Main(string[] args)
		{
			Bonus();

			//Useful File methods

			File.ReadAllText("path");
			File.ReadAllLines("path");
			File.ReadAllBytes("path");

			//

			File.WriteAllText("path", "");
			File.WriteAllLines("path", new string[] { "", "", "" });
			File.WriteAllBytes("path", new byte[] { });

			//

			File.AppendAllText("path", "");
			File.AppendAllLines("path", new string[] { "", "" });


		}

		static void EX1()
		{
			string name = Console.ReadLine();
			FileInfo file = new FileInfo(name);
			if (!file.Exists) file.Create().Close();
		}

		static void EX2()
		{
			string filename = "ex2.txt";
			string[] names = File.ReadAllText(filename).Split(",");

			foreach (string n in names) Console.WriteLine(n);
		}

		static void EX3()
		{
			string filename = Console.ReadLine();
			FileInfo file = new FileInfo(filename);
			if (file.Exists) file.Delete();
		}

		static void Bonus()
		{
			string filename = Console.ReadLine();
			FileStream stream = new FileStream(filename, FileMode.OpenOrCreate);

			StringBuilder sb = new StringBuilder();
			int b;
			while ((b = stream.ReadByte()) != -1)
			{
				if (b != 'a') sb.Append((char)b);
			}
			stream.Close();

			File.WriteAllText(filename, sb.ToString()); //write the new text to file
		}
	}
}
