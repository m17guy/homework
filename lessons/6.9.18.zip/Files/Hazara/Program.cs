﻿using System;

namespace Hazara
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				int digit = int.Parse(Console.ReadLine());

				string[] names = { "Zero", "One", "Two", "Three" };

				Console.WriteLine(names[digit]);
			}
			catch (IndexOutOfRangeException e)
			{
				Console.WriteLine("out of range");
			}
			catch(Exception e)
			{
				Console.WriteLine("invalid input for digits");
			}

			new Toy("bubu", -10.9);
		}
	}
}
