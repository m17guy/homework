﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hazara
{
	abstract class Product
	{
		protected string name;
		protected double price;

		protected Product(string name, double price)
		{
			if (price < 0) throw new ArgumentException("price cannot be negative");
			this.name = name;
			this.price = price;

		}

		public string Name
		{
			set => this.name = value;
		}

		public double Price
		{
			set => this.price = value;
		}
	}
}
